# Import necessary libraries
import requests
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Function to fetch weather data from a sample API
def fetch_weather_data(city):
    api_key = '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'  
    api_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'
    response = requests.get(api_url)
    
    if response.status_code == 200:
        return response.json()
    else:
        return None

# Function to process and analyze weather data using NumPy and Pandas
def analyze_weather_data(data):
    # Extract relevant information using regular expressions
    temperature = re.search(r'"temp":(\d+\.\d+)', str(data)).group(1)
    humidity = re.search(r'"humidity":(\d+)', str(data)).group(1)
    
    # Convert data to NumPy array for analysis
    temperature_array = np.array(float(temperature))
    humidity_array = np.array(int(humidity))
    
    return temperature_array, humidity_array

# Function to visualize weather data using Matplotlib
def visualize_weather_data(temperature, humidity):
    plt.figure(figsize=(8, 6))
    plt.subplot(2, 1, 1)
    plt.bar(['Temperature'], [temperature], color='orange')
    plt.ylabel('Temperature (Celsius)')
    plt.title('Weather Information')
    
    plt.subplot(2, 1, 2)
    plt.bar(['Humidity'], [humidity], color='blue')
    plt.ylabel('Humidity (%)')
    
    plt.show()

if __name__ == "__main__":
    # Fetch weather data for a specific city
    city_name = 'Berlin'  # Replace with your desired city
    weather_data = fetch_weather_data(city_name)
    
    if weather_data:
        # Analyze weather data
        temperature, humidity = analyze_weather_data(weather_data)
        print("Weather Analysis Result:")
        print(f"Temperature: {temperature} Celsius")
        print(f"Humidity: {humidity}%")
        
        # Visualize weather data
        visualize_weather_data(temperature, humidity)
    else:
        print("Failed to fetch weather data from the API.")
